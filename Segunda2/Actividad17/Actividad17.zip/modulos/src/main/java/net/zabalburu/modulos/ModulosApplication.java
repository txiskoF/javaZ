package net.zabalburu.modulos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModulosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModulosApplication.class, args);
	}

}
