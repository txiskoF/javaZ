package net.zabalburu.modulos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModulosApplicationTests {

	@Test
	void contextLoads() {
	}

}
