package net.zabalburu.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GatewayNotasApplication {

	public static void main(String[] args) {
		SpringApplication.run(GatewayNotasApplication.class, args);
	}

}
